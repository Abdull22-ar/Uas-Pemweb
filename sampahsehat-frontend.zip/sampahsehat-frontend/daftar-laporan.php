<?php
// Ambil daftar laporan dari API publik
$data     = [];
$errorMsg = null;
$api_url  = API_BASE_URL . '/api/laporan-publik';
$context  = stream_context_create(['http' => ['ignore_errors' => true, 'timeout' => 5]]);
$response = @file_get_contents($api_url, false, $context);

if ($response !== false) {
    $resData = json_decode($response, true);
    if (isset($resData['success']) && $resData['success'] && isset($resData['data'])) {
        $data = $resData['data'];
    } else {
        $errorMsg = $resData['message'] ?? 'Data laporan belum bisa dimuat.';
    }
} else {
    $errorMsg = 'Gagal terhubung ke server API.';
}

// Data dummy jika API tidak ada/kosong
if (empty($data)) {
    $errorMsg = null;
    $data = [
        [
            'kode_laporan' => 'SPH-0001',
            'kategori'     => 'Sampah Plastik',
            'petugas'      => 'Petugas A',
            'status'       => 'diproses',
            'label_status' => 'Diproses',
            'dibuat_pada'  => date('Y-m-d H:i:s', strtotime('-1 days')),
        ],
        [
            'kode_laporan' => 'SPH-0002',
            'kategori'     => 'Sampah Organik',
            'petugas'      => 'Petugas B',
            'status'       => 'selesai',
            'label_status' => 'Selesai',
            'dibuat_pada'  => date('Y-m-d H:i:s', strtotime('-2 days')),
        ],
        [
            'kode_laporan' => 'SPH-0003',
            'kategori'     => 'Limbah B3',
            'petugas'      => '',
            'status'       => 'baru',
            'label_status' => 'Baru',
            'dibuat_pada'  => date('Y-m-d H:i:s', strtotime('-1 hours')),
        ],
        [
            'kode_laporan' => 'SPH-0004',
            'kategori'     => 'Sampah Logam & Kaleng',
            'petugas'      => 'Petugas C',
            'status'       => 'selesai',
            'label_status' => 'Selesai',
            'dibuat_pada'  => date('Y-m-d H:i:s', strtotime('-3 days')),
        ],
        [
            'kode_laporan' => 'SPH-0005',
            'kategori'     => 'Sampah Medis & Bahan Infeksius',
            'petugas'      => '',
            'status'       => 'ditolak',
            'label_status' => 'Ditolak',
            'dibuat_pada'  => date('Y-m-d H:i:s', strtotime('-4 days')),
        ],
    ];
}

include 'components/navbar.php';
?>

<div class="card border-0 shadow-sm rounded-4">
    <div class="card-body p-4 p-md-5">
        <div class="mb-4">
            <h2 class="fw-bold text-dark mb-1">
                <i class="bi bi-list-ul text-primary me-2"></i>Daftar Laporan Publik
            </h2>
            <p class="text-muted small">Daftar laporan pengaduan sampah dari masyarakat. Identitas pelapor disembunyikan demi privasi.</p>
            <p class="text-muted small mb-0">
                Gunakan tombol <strong>Salin</strong> untuk menyimpan kode laporan, lalu cek status di halaman <em>Cek Status</em>.
            </p>
        </div>

        <?php if ($errorMsg): ?>
            <div class="alert alert-warning d-flex align-items-center rounded-3 p-3" role="alert">
                <i class="bi bi-exclamation-circle-fill fs-4 me-3"></i>
                <div class="small"><?= htmlspecialchars($errorMsg) ?></div>
            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-hover align-middle border">
                <thead class="table-light">
                    <tr>
                        <th class="py-3 text-secondary text-uppercase" style="font-size:0.8rem;letter-spacing:1px;">Kode Laporan</th>
                        <th class="py-3 text-secondary text-uppercase" style="font-size:0.8rem;letter-spacing:1px;">Kategori</th>
                        <th class="py-3 text-secondary text-uppercase" style="font-size:0.8rem;letter-spacing:1px;">Petugas</th>
                        <th class="py-3 text-secondary text-uppercase" style="font-size:0.8rem;letter-spacing:1px;">Status</th>
                        <th class="py-3 text-secondary text-uppercase" style="font-size:0.8rem;letter-spacing:1px;">Tanggal</th>
                        <th class="py-3 text-secondary text-uppercase text-center" style="font-size:0.8rem;letter-spacing:1px;">Aksi</th>
                    </tr>
                </thead>
                <tbody class="border-top-0">
                    <?php if (empty($data)): ?>
                        <tr>
                            <td colspan="6" class="text-center py-5 text-muted">
                                <i class="bi bi-inbox fs-1 d-block mb-2 opacity-50"></i>
                                Belum ada laporan publik yang tersedia.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($data as $row): ?>
                            <?php
                                $status = strtolower($row['status'] ?? '');
                                $badgeClass = 'bg-secondary text-white';
                                if ($status === 'baru')     $badgeClass = 'bg-info text-dark';
                                elseif ($status === 'diproses') $badgeClass = 'bg-warning text-dark';
                                elseif ($status === 'selesai')  $badgeClass = 'bg-success text-white';
                                elseif ($status === 'ditolak')  $badgeClass = 'bg-danger text-white';
                                $tgl = isset($row['dibuat_pada']) ? strtotime($row['dibuat_pada']) : time();
                            ?>
                            <tr>
                                <td style="min-width:180px;">
                                    <div class="d-flex align-items-center gap-2 flex-wrap">
                                        <span class="fw-semibold text-dark font-monospace" style="font-size:0.9rem;">
                                            <?= htmlspecialchars($row['kode_laporan'] ?? '-') ?>
                                        </span>
                                        <button type="button"
                                                class="btn btn-sm btn-outline-primary d-inline-flex align-items-center gap-1 py-1 copy-kode"
                                                data-kode="<?= htmlspecialchars($row['kode_laporan'] ?? '', ENT_QUOTES) ?>"
                                                title="Salin kode laporan">
                                            <i class="bi bi-clipboard" style="font-size:0.8rem;"></i>
                                            <span style="font-size:0.75rem;">Salin</span>
                                        </button>
                                    </div>
                                </td>
                                <td><?= htmlspecialchars($row['kategori'] ?? '-') ?></td>
                                <td class="small">
                                    <?php if (!empty($row['petugas'])): ?>
                                        <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-2 py-1">
                                            <i class="bi bi-person-badge me-1"></i><?= htmlspecialchars($row['petugas']) ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-muted">–</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge rounded-pill <?= $badgeClass ?> px-3 py-2 fw-medium">
                                        <?= htmlspecialchars($row['label_status'] ?? ucfirst($status)) ?>
                                    </span>
                                </td>
                                <td class="text-muted small"><?= date('d M Y, H:i', $tgl) ?></td>
                                <td class="text-center">
                                    <a href="cek-status.php?kode=<?= urlencode($row['kode_laporan'] ?? '') ?>"
                                       class="btn btn-sm btn-outline-secondary">
                                        <i class="bi bi-search me-1"></i>Cek
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.copy-kode').forEach(function (btn) {
    btn.addEventListener('click', function () {
        var kode   = this.dataset.kode;
        var tombol = this;
        var awal   = tombol.innerHTML;

        function ok() {
            tombol.innerHTML = '<i class="bi bi-clipboard-check" style="font-size:0.8rem;"></i><span style="font-size:0.75rem;">Tersalin!</span>';
            tombol.classList.replace('btn-outline-primary', 'btn-success');
            setTimeout(function () {
                tombol.innerHTML = awal;
                tombol.classList.replace('btn-success', 'btn-outline-primary');
            }, 2000);
        }

        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(kode).then(ok).catch(fallback);
        } else { fallback(); }

        function fallback() {
            var ta = document.createElement('textarea');
            ta.value = kode;
            ta.style.cssText = 'position:absolute;left:-9999px';
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
            ok();
        }
    });
});
</script>

<?php include 'components/footer.php'; ?>
