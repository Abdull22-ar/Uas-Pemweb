<?php
// Konfigurasi base URL aplikasi backend/API.
// Simpan tanpa trailing slash agar konsisten saat digabung dengan path endpoint.
$backendBaseUrl = 'https://silaris.my.id';

define('API_BASE_URL', rtrim($backendBaseUrl, '/'));
define('ADMIN_DASHBOARD_URL', API_BASE_URL . '/admin/dashboard');
?>
